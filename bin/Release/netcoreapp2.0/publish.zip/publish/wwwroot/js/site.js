﻿// Write your Javascript code.

